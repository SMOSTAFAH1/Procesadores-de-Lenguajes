
public class GestorErrores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static char[] error(char accion) {
		// TODO Auto-generated method stub
		return null;
	}

}
